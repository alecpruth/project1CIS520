/////////////////////////////////////////////////////////////////////////
// $Id: scancodes.h,v 1.9 2009/12/04 19:50:29 sshwarts Exp $
/////////////////////////////////////////////////////////////////////////
//
//  Copyright (C) 2002-2009  The Bochs Project
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Lesser General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//  Lesser General Public License for more details.
//
//  You should have received a copy of the GNU Lesser General Public
//  License along with this library; if not, write to the Free Software
//  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301 USA

#ifndef BX_SCANCODES_H
#define BX_SCANCODES_H

// Translation table of the 8042
extern unsigned char translation8042[256];

typedef struct {
  const char *make;
  const char *brek;
} scancode;

// Scancodes table
extern scancode scancodes[BX_KEY_NBKEYS][3];

#endif
